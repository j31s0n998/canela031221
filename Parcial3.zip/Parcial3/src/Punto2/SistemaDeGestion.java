/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto2;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author 
 */
public class SistemaDeGestion {
     public static void main(String[] args) {
        Administrador admin = new Administrador();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Agregar empleado");
            System.out.println("2. Registrar horas trabajadas");
            System.out.println("3. Calcular salarios");
            System.out.println("4. Solicitar vacaciones");
            System.out.println("5. Aprobar vacaciones");
            System.out.println("6. Generar informe de nómina");
            System.out.println("7. Salir");
            System.out.print("Elija una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();  

            switch (opcion) {
                case 1:
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Cargo: ");
                    String cargo = scanner.nextLine();
                    System.out.print("Salario por hora: ");
                    double salarioPorHora = scanner.nextDouble();
                    System.out.print("Fecha de contratación (AAAA-MM-DD): ");
                    LocalDate fechaContratacion = LocalDate.parse(scanner.next());
                    admin.agregarEmpleado(nombre, cargo, salarioPorHora, fechaContratacion);
                    break;
                case 2:
                    System.out.print("Nombre del empleado: ");
                    String nombreEmpleado = scanner.nextLine();
                    Empleado empleado = admin.obtenerEmpleado(nombreEmpleado);
                    if (empleado != null) {
                        System.out.print("Horas trabajadas: ");
                        double horas = scanner.nextDouble();
                        empleado.registrarHoras(horas);
                    } else {
                        System.out.println("Empleado no encontrado.");
                    }
                    break;
                case 3:
                    admin.calcularSalarios();
                    break;
                case 4:
                    System.out.print("Nombre del empleado: ");
                    nombreEmpleado = scanner.nextLine();
                    empleado = admin.obtenerEmpleado(nombreEmpleado);
                    if (empleado != null) {
                        System.out.print("Fecha de vacaciones solicitadas (AAAA-MM-DD): ");
                        LocalDate fechaVacaciones = LocalDate.parse(scanner.next());
                        empleado.solicitarVacaciones(fechaVacaciones);
                    } else {
                        System.out.println("Empleado no encontrado.");
                    }
                    break;
                case 5:
                    System.out.print("Nombre del empleado: ");
                    nombreEmpleado = scanner.nextLine();
                    empleado = admin.obtenerEmpleado(nombreEmpleado);
                    if (empleado != null) {
                        System.out.print("Fecha de vacaciones a aprobar (AAAA-MM-DD): ");
                        LocalDate fechaAprobar = LocalDate.parse(scanner.next());
                        admin.aprobarVacaciones(empleado, fechaAprobar);
                    } else {
                        System.out.println("Empleado no encontrado.");
                    }
                    break;
                case 6:
                    admin.generarInformeNomina();
                    break;
                case 7:
                    System.out.println("Saliendo del sistema...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
    
}
