/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 
 */
public class Administrador {
    private List<Empleado> empleados;

    public Administrador() {
        this.empleados = new ArrayList<>();
    }

    public void agregarEmpleado(String nombre, String cargo, double salarioPorHora, LocalDate fechaContratacion) {
        Empleado nuevoEmpleado = new Empleado(nombre, cargo, salarioPorHora, fechaContratacion);
        empleados.add(nuevoEmpleado);
    }

    public void calcularSalarios() {
        for (Empleado e : empleados) {
            double salario = e.getHorasTrabajadas() * e.getSalarioPorHora();
            System.out.println("Empleado: " + e.getNombre() + ", Salario Calculado: " + salario);
        }
    }

    public void aprobarVacaciones(Empleado empleado, LocalDate fecha) {
        if (empleado.getVacacionesSolicitadas().contains(fecha)) {
            System.out.println("Vacaciones aprobadas para " + empleado.getNombre() + " en la fecha: " + fecha);
        } else {
            System.out.println("No hay solicitud de vacaciones para esta fecha.");
        }
    }

    public void generarInformeNomina() {
        System.out.println("Informe de Nómina Mensual:");
        for (Empleado e : empleados) {
            double salario = e.getHorasTrabajadas() * e.getSalarioPorHora();
            System.out.println("Empleado: " + e.getNombre() + ", Cargo: " + e.getCargo() + ", Salario: " + salario);
        }
    }

    public Empleado obtenerEmpleado(String nombre) {
        for (Empleado e : empleados) {
            if (e.getNombre().equalsIgnoreCase(nombre)) {
                return e;
            }
        }
        return null;
    }
}
