/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 
 */
public class Empleado {
private String nombre;
    private String cargo;
    private double salarioPorHora;
    private LocalDate fechaContratacion;
    private double horasTrabajadas;
    private List<LocalDate> vacacionesSolicitadas;

    public Empleado(String nombre, String cargo, double salarioPorHora, LocalDate fechaContratacion) {
        this.nombre = nombre;
        this.cargo = cargo;
        this.salarioPorHora = salarioPorHora;
        this.fechaContratacion = fechaContratacion;
        this.horasTrabajadas = 0;
        this.vacacionesSolicitadas = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public double getSalarioPorHora() {
        return salarioPorHora;
    }

    public LocalDate getFechaContratacion() {
        return fechaContratacion;
    }

    public double getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public void registrarHoras(double horas) {
        this.horasTrabajadas += horas;
    }

    public List<LocalDate> getVacacionesSolicitadas() {
        return vacacionesSolicitadas;
    }

    public void solicitarVacaciones(LocalDate fecha) {
        vacacionesSolicitadas.add(fecha);
    }
    
}
