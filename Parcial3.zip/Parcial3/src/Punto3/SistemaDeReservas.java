/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto3;

import java.util.Scanner;

/**
 *
 * @author 
 */
public class SistemaDeReservas {
    public static void main(String[] args) {
        AdministradorHotel adminHotel = new AdministradorHotel();
        Scanner scanner = new Scanner(System.in);

       
        adminHotel.agregarHabitacion(101, "Simple", 50.0, "Cama, Baño, WiFi");
        adminHotel.agregarHabitacion(102, "Doble", 80.0, "Cama Doble, Baño, WiFi, TV");
        adminHotel.agregarHabitacion(103, "Suite", 150.0, "Cama King, Baño, WiFi, TV, MiniBar");

        while (true) {
            System.out.println("1. Buscar habitaciones disponibles");
            System.out.println("2. Realizar reserva");
            System.out.println("3. Cancelar reserva");
            System.out.println("4. Gestionar disponibilidad de habitaciones");
            System.out.println("5. Salir");
            System.out.print("Elija una opcion: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();  // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    System.out.print("Fecha de entrada (AAAA-MM-DD): ");
                    String fechaEntrada = scanner.nextLine();
                    System.out.print("Fecha de salida (AAAA-MM-DD): ");
                    String fechaSalida = scanner.nextLine();
                    System.out.print("Número de huéspedes: ");
                    int numeroHuespedes = scanner.nextInt();
                    adminHotel.buscarHabitacionesDisponibles(fechaEntrada, fechaSalida, numeroHuespedes);
                    break;
                case 2:
                    System.out.print("Numero de habitacion: ");
                    int numeroHabitacion = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Fecha de entrada (AAAA-MM-DD): ");
                    fechaEntrada = scanner.nextLine();
                    System.out.print("Fecha de salida (AAAA-MM-DD): ");
                    fechaSalida = scanner.nextLine();
                    System.out.print("Numero de huéspedes: ");
                    numeroHuespedes = scanner.nextInt();
                    adminHotel.realizarReserva(numeroHabitacion, fechaEntrada, fechaSalida, numeroHuespedes);
                    break;
                case 3:
                    System.out.print("Numero de reserva: ");
                    int numeroReserva = scanner.nextInt();
                    adminHotel.cancelarReserva(numeroReserva);
                    break;
                case 4:
                    System.out.print("Numero de habitación: ");
                    numeroHabitacion = scanner.nextInt();
                    System.out.print("Disponibilidad (1: Disponible, 0: Ocupada): ");
                    boolean disponible = scanner.nextInt() == 1;
                    adminHotel.gestionarDisponibilidad(numeroHabitacion, disponible);
                    break;
                case 5:
                    System.out.println("Saliendo del sistema...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opcion no válida.");
            }
        }
    }
}
