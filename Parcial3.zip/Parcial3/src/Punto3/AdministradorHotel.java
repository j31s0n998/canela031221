/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 
 */
public class AdministradorHotel {
    private List<Habitacion> habitaciones;
    private List<Reserva> reservas;
    private int contadorReservas;

    public AdministradorHotel() {
        this.habitaciones = new ArrayList<>();
        this.reservas = new ArrayList<>();
        this.contadorReservas = 1;
    }

    public void agregarHabitacion(int numero, String tipo, double precioPorNoche, String comodidades) {
        Habitacion habitacion = new Habitacion(numero, tipo, precioPorNoche, comodidades);
        habitaciones.add(habitacion);
    }

    public void buscarHabitacionesDisponibles(String fechaEntrada, String fechaSalida, int numeroHuespedes) {
        System.out.println("Habitaciones disponibles:");
        for (Habitacion habitacion : habitaciones) {
            if (habitacion.isDisponible()) {
                System.out.println("Número: " + habitacion.getNumero() +
                        ", Tipo: " + habitacion.getTipo() +
                        ", Precio por Noche: " + habitacion.getPrecioPorNoche() +
                        ", Comodidades: " + habitacion.getComodidades());
            }
        }
    }

    public void realizarReserva(int numeroHabitacion, String fechaEntrada, String fechaSalida, int numeroHuespedes) {
        for (Habitacion habitacion : habitaciones) {
            if (habitacion.getNumero() == numeroHabitacion && habitacion.isDisponible()) {
                habitacion.setDisponible(false);
                Reserva reserva = new Reserva(contadorReservas, numeroHabitacion, fechaEntrada, fechaSalida, numeroHuespedes);
                reservas.add(reserva);
                System.out.println("Reserva realizada con éxito. Número de reserva: " + contadorReservas);
                contadorReservas++;
                return;
            }
        }
        System.out.println("Habitación no disponible.");
    }

    public void cancelarReserva(int numeroReserva) {
        for (Reserva reserva : reservas) {
            if (reserva.getNumeroReserva() == numeroReserva) {
                reservas.remove(reserva);
                for (Habitacion habitacion : habitaciones) {
                    if (habitacion.getNumero() == reserva.getNumeroHabitacion()) {
                        habitacion.setDisponible(true);
                        break;
                    }
                }
                System.out.println("Reserva cancelada con éxito.");
                return;
            }
        }
        System.out.println("Número de reserva no encontrado.");
    }

    public void gestionarDisponibilidad(int numeroHabitacion, boolean disponible) {
        for (Habitacion habitacion : habitaciones) {
            if (habitacion.getNumero() == numeroHabitacion) {
                habitacion.setDisponible(disponible);
                System.out.println("Disponibilidad de la habitación actualizada.");
                return;
            }
        }
        System.out.println("Número de habitación no encontrado.");
    }
}
