/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto3;

/**
 *
 * @author 
 */
public class Reserva {
    private int numeroReserva;
    private int numeroHabitacion;
    private String fechaEntrada;
    private String fechaSalida;
    private int numeroHuespedes;

    public Reserva(int numeroReserva, int numeroHabitacion, String fechaEntrada, String fechaSalida, int numeroHuespedes) {
        this.numeroReserva = numeroReserva;
        this.numeroHabitacion = numeroHabitacion;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.numeroHuespedes = numeroHuespedes;
    }

    public int getNumeroReserva() {
        return numeroReserva;
    }

    public int getNumeroHabitacion() {
        return numeroHabitacion;
    }

    public String getFechaEntrada() {
        return fechaEntrada;
    }

    public String getFechaSalida() {
        return fechaSalida;
    }

    public int getNumeroHuespedes() {
        return numeroHuespedes;
    }
}
