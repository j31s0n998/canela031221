/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author 
 */
public class Inventario {
     List<Producto> productos = new ArrayList<>();

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public List<Producto> buscarProductoPorNombre(String nombre) {
        List<Producto> resultados = new ArrayList<>();
        for (Producto producto : productos) {
            if (producto.nombre.equalsIgnoreCase(nombre)) {
                resultados.add(producto);
            }
        }
        return resultados;
    }

    public List<Producto> buscarProductoPorCategoria(String categoria) {
        List<Producto> resultados = new ArrayList<>();
        for (Producto producto : productos) {
            if (producto.categoria.equalsIgnoreCase(categoria)) {
                resultados.add(producto);
            }
        }
        return resultados;
    }

    public void mostrarInventario() {
        for (Producto producto : productos) {
            System.out.println(producto);
        }
    }

    public boolean actualizarCantidadProducto(String nombre, int cantidadVendida) {
        for (Producto producto : productos) {
            if (producto.nombre.equalsIgnoreCase(nombre)) {
                if (producto.cantidad >= cantidadVendida) {
                    producto.cantidad -= cantidadVendida;
                    return true;
                } else {
                    System.out.println("Cantidad insuficiente en inventario.");
                    return false;
                }
            }
        }
        System.out.println("Producto no encontrado.");
        return false;
    }
}

class Pedido {
    String nombreProducto;
    int cantidad;

    public Pedido(String nombreProducto, int cantidad) {
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
    }
}


