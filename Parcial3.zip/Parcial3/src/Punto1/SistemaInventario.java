/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto1;

import java.util.List;
import java.util.Scanner;

/**
 *
 * @author 
 */
public class SistemaInventario {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventario inventario = new Inventario();

        while (true) {
            System.out.println("\nOpciones:");
            System.out.println("1. Agregar nuevo producto");
            System.out.println("2. Buscar producto por nombre");
            System.out.println("3. Buscar producto por categoria");
            System.out.println("4. Realizar pedido");
            System.out.println("5. Mostrar inventario");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine();  

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del producto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese la descripción del producto: ");
                    String descripcion = scanner.nextLine();
                    System.out.print("Ingrese el precio del producto: ");
                    double precio = scanner.nextDouble();
                    System.out.print("Ingrese la cantidad disponible: ");
                    int cantidad = scanner.nextInt();
                    scanner.nextLine();  
                    System.out.print("Ingrese la categoria del producto: ");
                    String categoria = scanner.nextLine();
                    Producto producto = new Producto(nombre, descripcion, precio, cantidad, categoria);
                    inventario.agregarProducto(producto);
                    System.out.println("Producto agregado exitosamente.");
                    break;
                case 2:
                    System.out.print("Ingrese el nombre del producto a buscar: ");
                    String nombreBusqueda = scanner.nextLine();
                    List<Producto> resultadosNombre = inventario.buscarProductoPorNombre(nombreBusqueda);
                    for (Producto p : resultadosNombre) {
                        System.out.println(p);
                    }
                    break;
                case 3:
                    System.out.print("Ingrese la categoría del producto a buscar: ");
                    String categoriaBusqueda = scanner.nextLine();
                    List<Producto> resultadosCategoria = inventario.buscarProductoPorCategoria(categoriaBusqueda);
                    for (Producto p : resultadosCategoria) {
                        System.out.println(p);
                    }
                    break;
                case 4:
                    System.out.print("Ingrese el nombre del producto a pedir: ");
                    String nombrePedido = scanner.nextLine();
                    System.out.print("Ingrese la cantidad deseada: ");
                    int cantidadPedido = scanner.nextInt();
                    scanner.nextLine(); 
                    boolean actualizado = inventario.actualizarCantidadProducto(nombrePedido, cantidadPedido);
                    if (actualizado) {
                        System.out.println("Pedido realizado exitosamente.");
                    }
                    break;
                case 5:
                    inventario.mostrarInventario();
                    break;
                case 6:
                    System.out.println("Saliendo del sistema...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }
}
