/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto4;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 
 */
public class Administrador {
   private List<Libro> catalogo;

    public Administrador() {
        this.catalogo = new ArrayList<>();
    }

    public void agregarLibro(String titulo, String autor, String categoria, int anioPublicacion) {
        Libro nuevoLibro = new Libro(titulo, autor, categoria, anioPublicacion);
        catalogo.add(nuevoLibro);
    }

    public void actualizarLibro(String titulo, String nuevoAutor, String nuevaCategoria, int nuevoAnio) {
        for (Libro libro : catalogo) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                libro = new Libro(titulo, nuevoAutor, nuevaCategoria, nuevoAnio);
                System.out.println("Libro actualizado: " + libro);
                return;
            }
        }
        System.out.println("Libro no encontrado.");
    }

    public void marcarLibroPrestado(String titulo) {
        for (Libro libro : catalogo) {
            if (libro.getTitulo().equalsIgnoreCase(titulo) && libro.isDisponible()) {
                libro.setDisponible(false);
                System.out.println("Libro marcado como prestado: " + libro);
                return;
            }
        }
        System.out.println("Libro no disponible o no encontrado.");
    }

    public void marcarLibroDevuelto(String titulo) {
        for (Libro libro : catalogo) {
            if (libro.getTitulo().equalsIgnoreCase(titulo) && !libro.isDisponible()) {
                libro.setDisponible(true);
                System.out.println("Libro marcado como devuelto: " + libro);
                return;
            }
        }
        System.out.println("Libro no encontrado o ya está disponible.");
    }

    public void generarInformePrestamos() {
        System.out.println("Informe de Préstamos y Devoluciones:");
        for (Libro libro : catalogo) {
            System.out.println(libro);
        }
    }

    public List<Libro> getCatalogo() {
        return catalogo;
    } 
}
