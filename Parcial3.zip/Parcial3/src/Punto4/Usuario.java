/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto4;

import java.util.List;

/**
 *
 * @author 
 */
public class Usuario {
     public void buscarLibro(List<Libro> catalogo, String criterio, String valor) {
        for (Libro libro : catalogo) {
            if ((criterio.equalsIgnoreCase("titulo") && libro.getTitulo().equalsIgnoreCase(valor)) ||
                (criterio.equalsIgnoreCase("autor") && libro.getAutor().equalsIgnoreCase(valor)) ||
                (criterio.equalsIgnoreCase("categoria") && libro.getCategoria().equalsIgnoreCase(valor))) {
                System.out.println(libro);
            }
        }
    }

    public void solicitarReserva(List<Libro> catalogo, String titulo) {
        for (Libro libro : catalogo) {
            if (libro.getTitulo().equalsIgnoreCase(titulo) && libro.isDisponible()) {
                libro.setDisponible(false);
                System.out.println("Libro reservado: " + libro);
                return;
            }
        }
        System.out.println("Libro no disponible o no encontrado.");
    }
}
