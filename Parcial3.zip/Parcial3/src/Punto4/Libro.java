/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto4;

/**
 *
 * @author 
 */
public class Libro {
       private String titulo;
    private String autor;
    private String categoria;
    private int anioPublicacion;
    private boolean disponible;

    public Libro(String titulo, String autor, String categoria, int anioPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
        this.anioPublicacion = anioPublicacion;
        this.disponible = true;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getCategoria() {
        return categoria;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public String toString() {
        return "Título: " + titulo + ", Autor: " + autor + ", Categoría: " + categoria +
               ", Año de Publicación: " + anioPublicacion + ", Disponible: " + (disponible ? "Sí" : "No");
    } 
}
