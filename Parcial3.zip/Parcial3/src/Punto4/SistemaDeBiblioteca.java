/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto4;

import java.util.Scanner;

/**
 *
 * @author
 */
public class SistemaDeBiblioteca {
    public static void main(String[] args) {
        Administrador admin = new Administrador();
        Usuario usuario = new Usuario();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Agregar libro");
            System.out.println("2. Actualizar libro");
            System.out.println("3. Marcar libro como prestado");
            System.out.println("4. Marcar libro como devuelto");
            System.out.println("5. Generar informe de prestamos y devoluciones");
            System.out.println("6. Buscar libro");
            System.out.println("7. Solicitar reserva de libro");
            System.out.println("8. Salir");
            System.out.print("Elija una opcion: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();
                    System.out.print("Autor: ");
                    String autor = scanner.nextLine();
                    System.out.print("Categoría: ");
                    String categoria = scanner.nextLine();
                    System.out.print("Año de Publicación: ");
                    int anio = scanner.nextInt();
                    admin.agregarLibro(titulo, autor, categoria, anio);
                    break;
                case 2:
                    System.out.print("Título del libro a actualizar: ");
                    titulo = scanner.nextLine();
                    System.out.print("Nuevo Autor: ");
                    autor = scanner.nextLine();
                    System.out.print("Nueva Categoría: ");
                    categoria = scanner.nextLine();
                    System.out.print("Nuevo Año de Publicación: ");
                    anio = scanner.nextInt();
                    admin.actualizarLibro(titulo, autor, categoria, anio);
                    break;
                case 3:
                    System.out.print("Título del libro a marcar como prestado: ");
                    titulo = scanner.nextLine();
                    admin.marcarLibroPrestado(titulo);
                    break;
                case 4:
                    System.out.print("Título del libro a marcar como devuelto: ");
                    titulo = scanner.nextLine();
                    admin.marcarLibroDevuelto(titulo);
                    break;
                case 5:
                    admin.generarInformePrestamos();
                    break;
                case 6:
                    System.out.print("Buscar por (titulo/autor/categoria): ");
                    String criterio = scanner.nextLine();
                    System.out.print("Valor: ");
                    String valor = scanner.nextLine();
                    usuario.buscarLibro(admin.getCatalogo(), criterio, valor);
                    break;
                case 7:
                    System.out.print("Título del libro a reservar: ");
                    titulo = scanner.nextLine();
                    usuario.solicitarReserva(admin.getCatalogo(), titulo);
                    break;
                case 8:
                    System.out.println("Saliendo del sistema...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
}
